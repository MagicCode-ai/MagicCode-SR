# MagicSR for Unreal Engine (v1.1.3)

Real-time AI super-resolution plugin for **Android** and **iOS** (UE 5.0–5.8).

- Website: https://www.magiccode-ai.com/
- GitHub: https://github.com/MagicCode-ai/SuperResolution
- Company: MagicCode Technology

## Install

1. Copy `MagicSR/` into your project's `Plugins/` folder.
2. Regenerate project files / open the editor and enable the plugin.
3. Models are under `Plugins/MagicSR/Content/MagicSRModels/`.
4. Call `UMagicSRBlueprintLibrary::SetModelDir` with the absolute path to that folder
   (or copy models into your packaged game content and point there).

## Engine versions

| Version | Store package note |
|---------|--------------------|
| UE 5.3 – 5.8 | Built / packaged on CI host when tools available |
| UE 5.0 – 5.2 | Supported in source; **verify locally** before Fab listing |

Use `plugin/store/scripts/package_ue_versions.sh` to emit per-version ZIPs.

## Quick start (Blueprint / C++)

1. `SetModelDir` → path containing the 8 GPU `.bin` files.
2. Each frame: `Enable` / `Enable_3params` / `Enable_4params` with a native texture.
3. On teardown: `Disable`.

Prefer the Enable/Disable path over low-level session APIs for GPU game pipelines.

## Bundled GPU models

Only the 8 default GPU bins ship in this Fab/store package.

**CPU models:** download separately from GitHub or https://www.magiccode-ai.com/
— they are intentionally not included in the store ZIP.

## Platforms

- Android (OpenGLES / Vulkan) + iOS (Metal)
- Editor desktop builds compile without linking mobile libs (Enable returns unsupported)

## Pricing

**Free for commercial use.** Optional paid services: https://www.magiccode-ai.com/

## License

See `LICENSE.md` and `ThirdPartyNotices.md`.

// Copyright (C) 2024-2026 MagicCode Technology Co., Ltd. All rights reserved.
#pragma once

#include "Modules/ModuleManager.h"

class FMagicSRModule : public IModuleInterface
{
public:
    virtual void StartupModule() override;
    virtual void ShutdownModule() override;
};

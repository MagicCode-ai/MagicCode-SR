// Copyright (C) 2024-2026 MagicCode Technology Co., Ltd. All rights reserved.
using System.IO;
using UnrealBuildTool;

public class MagicSR : ModuleRules
{
    public MagicSR(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

        PublicDependencyModuleNames.AddRange(
            new[]
            {
                "Core",
                "CoreUObject",
                "Engine",
                "RHI",
                "RenderCore",
                "Renderer"
            });

        // Self-contained store layout: ThirdParty next to Source/
        string pluginRoot = Path.GetFullPath(Path.Combine(ModuleDirectory, "../.."));
        string thirdPartyInclude = Path.Combine(pluginRoot, "ThirdParty", "Include");
        string thirdPartyLib = Path.Combine(pluginRoot, "ThirdParty", "Lib");

        PublicIncludePaths.Add(thirdPartyInclude);

        // Android/iOS only for Fab/store builds. Link combined enable+core static lib.
        if (Target.Platform == UnrealTargetPlatform.Android)
        {
            string androidLib = Path.Combine(thirdPartyLib, "Android", "libmagic_sr_enable.a");
            if (!File.Exists(androidLib))
            {
                throw new System.Exception("Missing MagicSR Android library: " + androidLib);
            }

            PublicAdditionalLibraries.Add(androidLib);
            PublicSystemLibraries.Add("log");
            PublicSystemLibraries.Add("android");
            PublicSystemLibraries.Add("GLESv3");
            PublicSystemLibraries.Add("EGL");
            PublicSystemLibraries.Add("vulkan");
            PublicSystemLibraries.Add("z");
            PublicDefinitions.Add("MAGIC_SR_ANDROID=1");
            PublicDefinitions.Add("SYS_ANDROID=1");
            PublicDefinitions.Add("VULKAN=1");
            PublicDefinitions.Add("OpenGLES=1");
            PublicDefinitions.Add("MAGIC_SR_IOS=0");
            PublicDefinitions.Add("MAGIC_SR_MAC=0");
            PublicDefinitions.Add("MAGIC_SR_WINDOWS=0");
        }
        else if (Target.Platform == UnrealTargetPlatform.IOS)
        {
            string iosLib = Path.Combine(thirdPartyLib, "IOS", "libmagic_sr_enable.a");
            if (!File.Exists(iosLib))
            {
                throw new System.Exception("Missing MagicSR iOS library: " + iosLib);
            }

            PublicAdditionalLibraries.Add(iosLib);
            PublicFrameworks.AddRange(
                new[]
                {
                    "Metal",
                    "MetalKit",
                    "MetalPerformanceShaders",
                    "QuartzCore",
                    "CoreVideo",
                    "Foundation"
                });
            PublicSystemLibraries.Add("z");
            PublicDefinitions.Add("MAGIC_SR_ANDROID=0");
            PublicDefinitions.Add("MAGIC_SR_IOS=1");
            PublicDefinitions.Add("MAGIC_SR_MAC=0");
            PublicDefinitions.Add("MAGIC_SR_WINDOWS=0");
            PublicDefinitions.Add("SYS_IOS=1");
            PublicDefinitions.Add("HAVE_NEON=1");
        }
        else
        {
            // Editor / desktop: compile stubs only (no native SR).
            PublicDefinitions.Add("MAGIC_SR_ANDROID=0");
            PublicDefinitions.Add("MAGIC_SR_IOS=0");
            PublicDefinitions.Add("MAGIC_SR_MAC=0");
            PublicDefinitions.Add("MAGIC_SR_WINDOWS=0");
        }
    }
}

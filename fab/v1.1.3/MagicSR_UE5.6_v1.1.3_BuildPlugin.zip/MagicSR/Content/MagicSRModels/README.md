# MagicSR GPU models

Default GPU parameter bins for MagicSR v1.1.3.

Call `SetModelDir` pointing at this folder before `Enable`.

## Included

- `magic_metal_{highspeed,speed}_gpu_params.bin` — iOS Metal
- `magic_gles_{highspeed,speed}_gpu_params.bin` — Android OpenGLES
- `magic_vulkan_{highspeed,speed}_gpu_params.bin` — Android Vulkan
- `magic_gl_{highspeed,speed}_gpu_params.bin` — OpenGL

## CPU models (not included)

Download CPU / Neon bins from GitHub or the MagicCode website if you need them:
https://github.com/MagicCode-ai/SuperResolution  
https://www.magiccode-ai.com/
